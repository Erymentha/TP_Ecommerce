/**
 * 
 */
package com.adaming.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.adaming.entity.Produit;
import com.adaming.service.IAdminProduitMetier;

/**
 * COntroller PRODUIT
 * @author inti0392
 *
 */
@Controller
@RequestMapping(value = "/adminproduit")
public class AdminProduitsController {

	
	@Autowired
	private IAdminProduitMetier boutiqueManager;

	/**
	 * Setter du produit Manager
	 * @param produitManager
	 */
	public void setProduitManager(IAdminProduitMetier produitManager) {
		this.boutiqueManager = produitManager;
	}

	@RequestMapping(value = "/indexproduit", method = RequestMethod.GET)
	public String index() {
		// renvoie a l'accueil admin
		return "admin";
	}

	@RequestMapping(value = "/ajouterproduit", method = RequestMethod.POST)
	public String saveProd(@RequestBody Produit produit) {
		
		// ajout du produit depuis une page specifique : 
		
		// rajout dans la bdd
		boutiqueManager.ajouterProduit(produit);
		
		// renvoi vers la page admin
		return "admin";
	}

	// ?
	public byte[] photoCat() {
		return null;
	}

	/**
	 * Initialisation PRODUIT
	 * 
	 * @return
	 */
	@RequestMapping(value = "/addproduit", method = RequestMethod.GET)
	public ModelAndView initProduit() {
		// Nom logique VUE
		String viewName = "ajouterproduit";

		// D�finition un objet de commande (objet modele)
		String commande = "command";

		return new ModelAndView(viewName, commande, new Produit());
	}


	/*
	 * Richard : modification de l'url
	 * avant : "/supprimerproduit"
	 * apr�s : "/supprimerproduit/{idprod}"
	 */
	/**
	 * Supprimer un produit
	 * @param id : l'id du produit. Se trouve dans l'url
	 * @return : la redirection
	 */
	@RequestMapping(value = "/supprimerproduit/{idprod}", method = RequestMethod.POST)
	public String suppProd(@PathVariable("idprod") Long id) {
		
		// suppression de la bdd
		boutiqueManager.supprimerProduit(id);
		
		// renvoi � la page admin
		return "admin";
	}

	@RequestMapping(value = "/updateproduit", method = RequestMethod.POST)
	public String editProd(@RequestBody Produit produit) {
		
		// modif depuis une autre page : voir ajouterProduit
		
		// modification dans la bdd
		boutiqueManager.modifierProduit(produit);
		
		// renvoi � la page admin
		return "admin";
	}
}
