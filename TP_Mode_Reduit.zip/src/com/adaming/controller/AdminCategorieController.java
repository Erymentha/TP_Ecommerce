/**
 * 
 */
package com.adaming.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.adaming.entity.Categorie;
import com.adaming.service.IAdminCategorieMetier;

/**
 * Controller CATEGORIE
 * 
 * @author inti0392
 *
 */

@Controller
@RequestMapping(value = "/categories")
public class AdminCategorieController {

	@Autowired
	private IAdminCategorieMetier boutiqueManager;

	// private List<Categorie> listeCategorie =
	// boutiqueManager.listCategories();

	public void setCategorieManager(IAdminCategorieMetier categorieManager) {
		this.boutiqueManager = categorieManager;
	}

	@RequestMapping(value = "/indexcategorie", method = RequestMethod.GET)
	public String index() {
		// renvoie a l'accueil admin
		boutiqueManager.listCategories();
		return "categories";
	}

	/**
	 * Creation d'un objet Categorie Sera appel� lors de l'appuis sur le bouton
	 * ajouter categorie ou modifier categorie
	 * 
	 * @return
	 */
	@RequestMapping(value = "addcategorie", method = RequestMethod.GET)
	public ModelAndView initCategorie() {

		// Nom logique VUE
		String viewName = "ajouterunecategorie";

		// D�finition un objet de commande (objet modele)
		String commande = "commandecate";

		return new ModelAndView(viewName, commande, new Categorie());
	}

	@RequestMapping(value = "/ajoutercategorie", method = RequestMethod.POST)
	public String saveCat(ModelMap modele, @ModelAttribute("commandecate") Categorie categorie) {
		System.out.println("Cat id : " + categorie.getIdCategorie());

		// ==> RequestBody : fait a partir d'un formulaire externe. Autre jsp a
		// faire!
		boutiqueManager.ajouterCategorie(categorie);

		// Recup de la liste apr�s suppression
		List<Categorie> liste = boutiqueManager.listCategories();

		// MODELE � retourner
		// Le m�me nom de mod�le car la m�me utilisation ici
		modele.addAttribute("listeCategoriesKey", liste);
		// maj liste
		// listeCategorie = boutiqueManager.listCategories();
		// on renvoie sur la page admin
		return "categories";
	}

	// ? ==> totalement d'accord // Sur son exemple, il y avait les photos des
	// produits. Ici
	// c'est sans doute remplac� par des bytes (photo = suite tr�s longue de
	// bytes?)
	// ==> rectification. Sur son exemple, il faut rentrer une URL il me semble
	public byte[] getPhoto() {

		return null;
	}

	/**
	 * initialisation de la suppression Je n'ai pas r�ussi � faire mieux, navr�
	 * Lauren! Methode appel�e quand on acc�de au form supprimer.jsp, access
	 * denied
	 * 
	 * @return
	 */
	@RequestMapping(value = "suppronecategorie", method = RequestMethod.GET)
	public ModelAndView supprOneCategorie() {

		// Nom logique VUE
		String viewName = "supprimercategorie";

		// D�finition un objet de commande (objet modele)
		String commande = "commandecatesuppr";

		return new ModelAndView(viewName, commande, new Categorie());
	}

	@RequestMapping(value = "/supprimercategorie", method = RequestMethod.POST)
	public String supp(ModelMap modele, @ModelAttribute("commandecatesuppr") Categorie categorie ) {

		// System.out.println(categorie.getIdCategorie());
		// suppression par id
		boutiqueManager.supprimerCategorie(categorie.getIdCategorie());

		// Recup de la liste apr�s suppression
		List<Categorie> liste = boutiqueManager.listCategories();

		// MODELE � retourner
		// Le m�me nom de mod�le car la m�me utilisation ici
		modele.addAttribute("listeCategoriesKey", liste);

		// renvoi a l'index
		return "categories";
	}

	/*
	 * Richard : modification de l'url avant : "/supprimercategorie" apr�s :
	 * "/supprimercategorie/{id_cat}" Lauren : Suppression OK en cliquant sur
	 * Supprimer dans la jsp
	 */
	/**
	 * Suppression d'une categorie par ID
	 * 
	 * @param idcat
	 *            : l'id � supprimer, pass� dans l'url
	 * @return
	 */
	@RequestMapping(value = "/supprimercategorie/{idCat}", method = RequestMethod.GET)
	public String suppCat(ModelMap modele, @PathVariable("idCat") Long idCat) {

		System.out.println(idCat + "--------------");
		// System.out.println(categorie.getIdCategorie());
		// suppression par id
		boutiqueManager.supprimerCategorie(idCat);

		// Recup de la liste apr�s suppression
		List<Categorie> liste = boutiqueManager.listCategories();

		// MODELE � retourner
		// Le m�me nom de mod�le car la m�me utilisation ici
		modele.addAttribute("listeCategoriesKey", liste);

		// renvoi a l'index
		return "categories";
	}

	/**
	 * initialisation de l'�dition Je n'ai pas r�ussi � faire mieux, navr�
	 * Lauren!
	 * 
	 * @return
	 */
	@RequestMapping(value = "editonecategorie", method = RequestMethod.GET)
	public ModelAndView editOneCategorie() {

		// Nom logique VUE
		String viewName = "updatecategorie";

		// D�finition un objet de commande (objet modele)
		String commande = "commandecateedit";

		return new ModelAndView(viewName, commande, new Categorie());
	}

	/**
	 * Modifier une categorie
	 * 
	 * @param categorie
	 *            : la categorie � modifier
	 * @return
	 */
	@RequestMapping(value = "/updatecategorie", method = RequestMethod.POST)
	public String editCat(ModelMap modele, @ModelAttribute("commandecateedit") Categorie categorie) {
		// modification depuis un formulaire A FAIRE : nouvelle jsp a prevoir?
		// (idem add)

		boutiqueManager.modifierCategorie(categorie);

		// Recup de la liste apr�s suppression
		List<Categorie> liste = boutiqueManager.listCategories();

		// MODELE � retourner
		// Le m�me nom de mod�le car la m�me utilisation ici
		modele.addAttribute("listeCategoriesKey", liste);

		// renvoi a l'index
		return "categories";
	}

	/**
	 * Test affichage liste
	 * 
	 */
	@RequestMapping(value = "/listecategorie", method = RequestMethod.GET)
	public ModelAndView listerCategories() {

		// def une map pour stocker les donnees
		Map<String, Object> data = new HashMap<>();

		data.put("listeCategoriesKey", boutiqueManager.listCategories());

		// def du nom logique de la vue
		String viewName = "categories";

		// renvoi du ModelAndView
		return new ModelAndView(viewName, data);
	}

}
