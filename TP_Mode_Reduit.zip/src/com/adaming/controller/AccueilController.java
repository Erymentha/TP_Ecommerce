/**
 * 
 */
package com.adaming.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author inti0392
 *
 */
@Controller
public class AccueilController {

	/**
	 * 
	 * @param modele
	 *            : mod�le de donn�es � retourner vers la vue
	 * @return le nom logique
	 */
	// A nous de cr�er les m�thodes, pas d'interface
	@RequestMapping(value="/accueil", method = RequestMethod.GET)
	public String welcome(ModelMap modele) {

		// D�finir les donn�es � retourner vers la vue
		String nomModele = "nom";
		String objectModele = "Site du Ecommerce Nya";
		modele.addAttribute(nomModele, objectModele);

		modele.addAttribute("salutation", ":)");

		// D�finir le nom logique de la vue
		// On va retourner � accueil.jsp
		String viewName = "accueil";

		return viewName;
	}

	/**
	 * Page d'admin categorie
	 * 
	 * @return
	 */
	@RequestMapping(value = "/categories", method = RequestMethod.GET)
	public ModelAndView adminCategoriePage() {
		// Pareil que String ModelMap

		// MODELE
		ModelAndView modele = new ModelAndView();
		modele.addObject("titre", "Formulaire d'Authentification Spring Security - BDD");
		modele.addObject("message", "Categories Administrator Page");

		// VUE = .jsp
		modele.setViewName("categories");

		return modele;
	}

	

	/**
	 * Page d'admin produit
	 * 
	 * @return
	 */
	@RequestMapping(value = "/produits", method = RequestMethod.GET)
	public ModelAndView adminProduitPage() {
		// Pareil que String ModelMap

		// MODELE
		ModelAndView modele = new ModelAndView();
		modele.addObject("titre", "Formulaire d'Authentification Spring Security - BDD");
		modele.addObject("message", "Product Administrator Page");

		// VUE = .jsp
		modele.setViewName("produits");

		return modele;
	}

	
	
	
	
	
	
	
	
	
	
	/**
	 * Page de login
	 * 
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView loginPage(@RequestParam(value = "error", required = false) String pError,
			@RequestParam(value = "logout", required = false) String pLogout) {

		ModelAndView modele = new ModelAndView();

		// MODELE
		if (pError != null) {
			modele.addObject("erreur", "Invalid UserName and Password");
		}
		if (pLogout != null) {
			modele.addObject("message", "You've been logged out Successfully");
		}

		// VUE .jsp
		modele.setViewName("login");

		return modele;
	}

	/**
	 * Page en cas de 403 : acc�s refus�
	 * 
	 * @return
	 */
	@RequestMapping(name = "/403", method = RequestMethod.GET)
	public ModelAndView accessDeniedPage() {

		ModelAndView modele = new ModelAndView();

		// Verif si le user est conenct�
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (auth instanceof AnonymousAuthenticationToken) {
			UserDetails details = (UserDetails) auth.getDetails();
			modele.addObject("user", details.getUsername());
		}

		// VUE .jsp
		modele.setViewName("403");

		return modele;
	}
}
