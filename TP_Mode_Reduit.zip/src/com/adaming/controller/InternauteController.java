/**
 * 
 */
package com.adaming.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.adaming.entity.Produit;
import com.adaming.service.IInternauteBoutique;

/**
 * Controller INTERNAUTE
 * 
 * @author inti0392
 *
 */
@Controller
@RequestMapping(value = "/accueil")
public class InternauteController {

	@Autowired
	private IInternauteBoutique boutiqueManager;

	public void setInternauteBoutique(IInternauteBoutique internauteBoutique) {
		this.boutiqueManager = internauteBoutique;
	}
	
	@RequestMapping(value="/listproduit", method=RequestMethod.GET)
	public List<Produit> getAllProduit(){
		return boutiqueManager.listproduits();
	}

}
