/**
 * 
 */
package com.adaming.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author inti0392
 *
 */
@Entity(name = "role")
@Table(name = "roles")
public class Role {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_role")
	private int id;

	@Column(name = "role_name")
	private String roleName;

	// --------------------------
	// -------ASSOCIATIONS-------
	// --------------------------
	// Many to One user
	@ManyToOne
	@JoinColumn(name = "user_id", referencedColumnName = "id_user")
	private Utilisateur utilisateur;

	/**
	 * Constructeurs
	 */
	public Role() {
		super();
	}

	public Role(int id, String roleName) {
		super();
		this.id = id;
		this.roleName = roleName;
	}

	public Role(String roleName) {
		super();
		this.roleName = roleName;
	}

	// Get Set
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Utilisateur getUser() {
		return utilisateur;
	}

	public void setUser(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}
}
