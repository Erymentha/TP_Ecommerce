/**
 * 
 */
package com.adaming.entity;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Classe de PRODUIT
 * 
 * @author inti0392
 *
 */
@Entity(name = "produit")
@Table(name = "produits")
public class Produit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_produit")
	private Long id_produit;

	@Column(name = "designation")
	private String designation;

	@Column(name = "description_produit")
	private String description;

	@Column(name = "prix")
	private double prix;

	@Column(name = "quantite_produit")
	private int quantite;

	@Column(name = "selection" , columnDefinition="BIT") // Richard : rajout column definition car j'avais une erreur � ce niveau : found bit, expected boolean
	private boolean selection;

	@Column(name = "photo")
	private String photo;

	// --------------------------
	// -------ASSOCIATIONS-------
	// --------------------------
	// Many to One categorie
	@ManyToOne
	@JoinColumn(name = "categorie_id", referencedColumnName = "id_categorie")
	private Categorie categorie;
	
	//ManyToMany commande
	@ManyToMany(mappedBy = "produits")
	private Collection<Commande> commandes;

	/**
	 * Constructeurs
	 */
	public Produit() {
		super();
	}

	public Produit(Long id_produit, String designation, String description, double prix, int quantite,
			boolean selection, String photo) {
		super();
		this.id_produit = id_produit;
		this.designation = designation;
		this.description = description;
		this.prix = prix;
		this.quantite = quantite;
		this.selection = selection;
		this.photo = photo;
	}

	public Produit(String designation, String description, double prix, int quantite, boolean selection, String photo) {
		super();
		this.designation = designation;
		this.description = description;
		this.prix = prix;
		this.quantite = quantite;
		this.selection = selection;
		this.photo = photo;
	}

	/**
	 * Getters & Setters
	 */

	public long getId_produit() {
		return id_produit;
	}

	public void setId_produit(Long id_produit) {
		this.id_produit = id_produit;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public int getQuantite() {
		return quantite;
	}

	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}

	public boolean isSelection() {
		return selection;
	}

	public void setSelection(boolean selection) {
		this.selection = selection;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	@Override
	public String toString() {
		return "Produit [id_produit=" + id_produit + ", designation=" + designation + ", description=" + description
				+ ", prix=" + prix + ", quantite=" + quantite + ", selection=" + selection + ", photo=" + photo + "]";
	}

}
