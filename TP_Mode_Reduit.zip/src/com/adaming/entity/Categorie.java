/**
 * 
 */
package com.adaming.entity;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Classe de CATEGORIE
 * 
 * @author inti0392
 *
 */
@Entity(name = "categorie")
@Table(name = "categories")
public class Categorie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_categorie")
	private Long idCategorie;

	@Column(name = "nom_categorie")
	private String nomCategorie;

	@Column(name = "photo")
	private byte photo;

	@Column(name = "description_categorie")
	private String description;

	// --------------------------
	// -------ASSOCIATIONS-------
	// --------------------------
	// One to many roles
	// Mapped by cot� *
	@OneToMany(mappedBy = "categorie")
	private Collection<Produit> produits;

	/**
	 * Constructeurs
	 */
	public Categorie() {
		super();
	}

	public Categorie(Long idCategorie, String nomCategorie, byte photo, String description) {
		super();
		this.idCategorie = idCategorie;
		this.nomCategorie = nomCategorie;
		this.photo = photo;
		this.description = description;
	}

	public Categorie(String nomCategorie, byte photo, String description) {
		super();
		this.nomCategorie = nomCategorie;
		this.photo = photo;
		this.description = description;
	}

	/**
	 * Getters & Setters
	 * 
	 * @return
	 */
	public Long getIdCategorie() {
		return idCategorie;
	}

	public void setIdCategorie(Long idCategorie) {
		this.idCategorie = idCategorie;
	}

	public String getNomCategorie() {
		return nomCategorie;
	}

	public void setNomCategorie(String nomCategorie) {
		this.nomCategorie = nomCategorie;
	}

	public byte getPhoto() {
		return photo;
	}

	public void setPhoto(byte photo) {
		this.photo = photo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Categorie [idCategorie=" + idCategorie + ", nomCategorie=" + nomCategorie + ", photo=" + photo
				+ ", description=" + description + "]";
	}

}
