/**
 * 
 */
package com.adaming.dao;

import java.util.List;

import com.adaming.entity.Categorie;
import com.adaming.entity.Produit;
import com.adaming.entity.Role;
import com.adaming.entity.Utilisateur;

/**
 * Interface de DAO
 * @author inti0392
 *
 */
public interface IBoutiqueDao {
	public Long ajouterCategorie(Categorie c);

	public List<Categorie> listCategories();

	public Categorie getCategorie(Long idCat);

	public void supprimerCategrorie(Long idcat);

	public void modifierCategorie(Categorie c);

	public Long ajouterProduit(Produit p);

	public List<Produit> listproduits();

	public List<Produit> produitsParMotCle(String mc);

	public List<Produit> produitsParCategorie(Long idCat);

	public List<Produit> produitsSelectionnes();

	public Produit getProduit(Long idP);

	public void supprimerProduit(Long idP);

	public void modifierProduit(Produit p);

	public void ajouterUser(Utilisateur u);

	public void attribuerRole(Role r, Long userID);

	// public Commande enregistrerCommande(GestionPanier p, Client c);
}
