/**
 * 
 */
package com.adaming.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.adaming.entity.Categorie;
import com.adaming.entity.Produit;
import com.adaming.entity.Role;
import com.adaming.entity.Utilisateur;

/**
 * Impl�mentation de la DAO
 * 
 * @author inti0392
 *
 */
@Transactional
@Repository
public class BoutiqueDaoImpl implements IBoutiqueDao {

	@Autowired
	private SessionFactory factory;

	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}

	/**
	 * AJOUT CATEGORIE
	 */
	@Override
	public Long ajouterCategorie(Categorie pCategorie) {

		Session session = factory.getCurrentSession();

		session.save(pCategorie);

		return pCategorie.getIdCategorie();
	}

	/**
	 * GET LIST CATEGORIE
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Categorie> listCategories() {

		List<Categorie> listeCategories = new ArrayList<>();

		Session session = factory.getCurrentSession();

		Criteria req = session.createCriteria(Categorie.class);

		listeCategories = req.list();

		return listeCategories;
	}

	/**
	 * GET CATEGORIE BY ID
	 */
	@Override
	public Categorie getCategorie(Long idCat) {

		Session session = factory.getCurrentSession();

		String req = "FROM categorie c WHERE c.idCategorie = :id";

		Query query = session.createQuery(req);

		query.setParameter("id", idCat);

		Categorie categorie = (Categorie) query.uniqueResult();

		return categorie;
	}

	/**
	 * DELETE CATEGORIE
	 */
	@Override
	public void supprimerCategrorie(Long idcat) {

		Session session = factory.getCurrentSession();

		String req = "DELETE FROM categorie c WHERE c.idCategorie =:id";
		Query query = session.createQuery(req);
		query.setParameter("id", idcat);

		query.executeUpdate();
	}

	/**
	 * UPDATE CATEGORIE
	 */
	@Override
	public void modifierCategorie(Categorie c) {
		Session session = factory.getCurrentSession();

		session.merge(c);

	}

	/**
	 * ADD PRODUIT
	 */
	@Override
	public Long ajouterProduit(Produit p) {
		Session session = factory.getCurrentSession();

		session.save(p);

		return p.getId_produit();
	}

	/**
	 * GET LIST PRODUIT
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Produit> listproduits() {
		List<Produit> listeProduit = new ArrayList<>();

		Session session = factory.getCurrentSession();

		Criteria req = session.createCriteria(Categorie.class);

		listeProduit = req.list();

		return listeProduit;
	}

	/**
	 * Chercher un PRODUIT par mot
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Produit> produitsParMotCle(String mc) {

		Session session = factory.getCurrentSession();

		String req = "FROM produit p WHERE p.designation = :%pM%";

		Query query = session.createQuery(req);

		query.setParameter("pM", mc);

		List<Produit> listeProduit = query.list();

		return listeProduit;
	}

	/**
	 * Chercher un PRODUIT par CATEGORIE
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Produit> produitsParCategorie(Long idCat) {
		Session session = factory.getCurrentSession();

		String req = "FROM produit p WHERE p.categorie_id = :id";

		Query query = session.createQuery(req);

		query.setParameter("id", idCat);

		List<Produit> listeProduit = query.list();

		return listeProduit;
	}

	/**
	 * Chercher PRODUIT par SELECTION
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Produit> produitsSelectionnes() {
		Session session = factory.getCurrentSession();

		String req = "FROM produit p WHERE p.selection = 1";

		Query query = session.createQuery(req);

		List<Produit> listeProduit = query.list();

		return listeProduit;
	}

	/**
	 * Chercher PRODUIT par ID
	 */
	@Override
	public Produit getProduit(Long idP) {
		Session session = factory.getCurrentSession();

		String req = "FROM produit p WHERE p.id_produit = :id";

		Query query = session.createQuery(req);

		query.setParameter("id", idP);

		Produit produit = (Produit) query.uniqueResult();

		return produit;
	}

	/**
	 * DELETE PRODUIT
	 */
	@Override
	public void supprimerProduit(Long idP) {

		Session session = factory.getCurrentSession();

		String hslReq = "DELETE FROM produit p WHERE p.id_produit =:id";

		Query query = session.createQuery(hslReq);

		query.setParameter("id", idP);

		query.executeUpdate();

	}

	/**
	 * UPDATE PRODUIT
	 */
	@Override
	public void modifierProduit(Produit p) {

		Session session = factory.getCurrentSession();

		session.merge(p);

	}

	/**
	 * ADD USER
	 */
	@Override
	public void ajouterUser(Utilisateur u) {
		Session session = factory.getCurrentSession();

		session.save(u);

	}

	/**
	 * SET ROLE
	 */
	@Override
	public void attribuerRole(Role r, Long userID) {
		Session session = factory.getCurrentSession();

		String hql = "UPDATE role r SET r.user_id = :idU WHERE r.id_role = :idR ";
		Query query = session.createQuery(hql);
		query.setParameter("idU", userID);
		query.setParameter("idR", r.getId());

		query.executeUpdate();
	}

}
