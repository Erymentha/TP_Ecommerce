/**
 * 
 */
package com.adaming.service;

import com.adaming.entity.Produit;

/**
 * Interface SERVICE PRODUIT
 * @author inti0392
 *
 */
public interface IAdminProduitMetier {
	public Long ajouterProduit(Produit p);

	public void supprimerProduit(Long idP);

	public void modifierProduit(Produit p);
}
