/**
 * 
 */
package com.adaming.service;

import java.util.List;

import com.adaming.entity.Categorie;
import com.adaming.entity.Role;
import com.adaming.entity.Utilisateur;

/**
 * Interface SERVICE CATEGORIE
 * 
 * @author inti0392
 *
 */
public interface IAdminCategorieMetier {

	public Long ajouterCategorie(Categorie c);

	public void supprimerCategorie(Long idcat);

	public void modifierCategorie(Categorie c);

	public void ajouterUser(Utilisateur u);

	public void attribuerRole(Role r, Long userID);
	
	public List<Categorie> listCategories();
}
