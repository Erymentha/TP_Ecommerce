/**
 * 
 */
package com.adaming.service;

import java.util.List;

import com.adaming.entity.Categorie;
import com.adaming.entity.Produit;

/**
 * Interface SERVICE INTERNAUTE
 * @author inti0392
 *
 */
public interface IInternauteBoutique {

	public List<Categorie> listCategories();

	public Categorie getCategorie(Long idCat);

	public List<Produit> listproduits();

	public List<Produit> produitsParMotCle(String mc);

	public List<Produit> produitsParCategorie(Long idCat);

	public List<Produit> produitsSelectionnes();

	public Produit getProduit(Long idP);

	//public Commande enregistrerCommande(GestionPanier p, Client c);
}
