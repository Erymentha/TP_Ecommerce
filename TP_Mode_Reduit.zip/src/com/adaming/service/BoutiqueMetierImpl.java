/**
 * 
 */
package com.adaming.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adaming.dao.IBoutiqueDao;
import com.adaming.entity.Categorie;
import com.adaming.entity.Produit;
import com.adaming.entity.Role;
import com.adaming.entity.Utilisateur;

/**
 * SERVICE
 * 
 * @author inti0392
 *
 */
@Service
public class BoutiqueMetierImpl implements IAdminCategorieMetier, IAdminProduitMetier, IInternauteBoutique {

	@Autowired
	private IBoutiqueDao boutiqueDao;

	
	
	public void setDao(IBoutiqueDao dao) {
		this.boutiqueDao = dao;
	}

	/**
	 * GET LIST CATEGORIE
	 */
	@Override
	public List<Categorie> listCategories() {

		return boutiqueDao.listCategories();
	}

	/**
	 * GET CATEGORIE
	 */
	@Override
	public Categorie getCategorie(Long idCat) {
		return boutiqueDao.getCategorie(idCat);
	}

	/**
	 * GET LIST PRODUIT
	 */
	@Override
	public List<Produit> listproduits() {
		return boutiqueDao.listproduits();
	}

	/**
	 * GET PRODUIT par MOT
	 */
	@Override
	public List<Produit> produitsParMotCle(String mc) {
		return boutiqueDao.produitsParMotCle(mc);
	}

	/**
	 * GET PRODUIT par CATEGORIE
	 */
	@Override
	public List<Produit> produitsParCategorie(Long idCat) {
		return boutiqueDao.produitsParCategorie(idCat);
	}

	/**
	 * GET PRODUIT SELECT
	 */
	@Override
	public List<Produit> produitsSelectionnes() {
		return boutiqueDao.produitsSelectionnes();
	}

	/**
	 * GET PRODUIT by ID
	 */
	@Override
	public Produit getProduit(Long idP) {
		return boutiqueDao.getProduit(idP);
	}

	/**
	 * ADD PRODUIT
	 */
	@Override
	public Long ajouterProduit(Produit p) {
		return boutiqueDao.ajouterProduit(p);
	}

	/**
	 * DELETE PRODUIT
	 */
	@Override
	public void supprimerProduit(Long idP) {
		boutiqueDao.supprimerProduit(idP);
	}

	/**
	 * UPDATE PRODUIT
	 */
	@Override
	public void modifierProduit(Produit p) {
		boutiqueDao.modifierProduit(p);
	}

	/**
	 * ADD CATEGORIE
	 */
	@Override
	public Long ajouterCategorie(Categorie c) {
		return boutiqueDao.ajouterCategorie(c);
	}

	/**
	 * DELETE CATEGORIE
	 */
	@Override
	public void supprimerCategorie(Long idcat) {
		boutiqueDao.supprimerCategrorie(idcat);
	}

	/**
	 * UPDATE CATEGORIE
	 */
	@Override
	public void modifierCategorie(Categorie c) {
		boutiqueDao.modifierCategorie(c);
	}

	/**
	 * ADD USER
	 */
	@Override
	public void ajouterUser(Utilisateur u) {
		boutiqueDao.ajouterUser(u);
	}

	/**
	 * UPDATE ROLE et USER
	 */
	@Override
	public void attribuerRole(Role r, Long userID) {
		boutiqueDao.attribuerRole(r, userID);
	}

}
